/*//iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package redes_practica_1;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author javier.castro.vazquez
 */


public class ServidorTCP {
    public static void main(String[] argv){
        if(argv.length!=1){
            System.exit(-1);
        }
        try {
            ServerSocket server_socket = new ServerSocket(Integer.parseInt(argv[0]));
            server_socket.setSoTimeout(30000);
            Socket conection_socket = null;
            while(true){
                conection_socket = server_socket.accept();
                InputStream entrada = conection_socket.getInputStream();
                OutputStream salida = conection_socket.getOutputStream();
                byte[] aux = new byte[1024];
                entrada.read(aux);
                salida.write(aux);
            }
        } catch (IOException ex) {
            Logger.getLogger(ServidorTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

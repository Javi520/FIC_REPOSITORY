/*//iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package redes_practica_1;

//imports
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 *
 * @author javier.castro.vazquez
 */
public class Copy {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        if(args.length!=2)
        {
            System.out.println("Error: No se proporcionan los argumentos como se debiere");
        }
        else
        {
            try{
                FileInputStream fichero_origen = new FileInputStream(args[0]);
                FileOutputStream fichero_destino = new FileOutputStream(args[1]);
                byte[] aux = new byte[1024];
                while(fichero_origen.read(aux)!=-1){
                    fichero_destino.write(aux);
                }
                fichero_origen.close();
                fichero_destino.close();
            }
            catch(Exception e){
                System.out.println("Error: Se ha producido un error "+e);
            }
            
        }
    }
    
}

/*//iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package redes_practica_1;

/**
 *
 * @author javier.castro.vazquez
 */


import java.net.*;

/**
 * Ejemplo que implementa un servidor de eco usando UDP.
 */
public class ServidorUDP {

    public static void main(String argv[]) {
        if (argv.length != 1) {
            System.err.println("Formato: ServidorUDP <puerto>");
            System.exit(-1);
        }
        DatagramSocket server_socket = null;
        try {
            InetAddress address = Inet4Address.getByName("localhost");
            System.out.println(Inet4Address.getByName("localhost"));
            server_socket = new DatagramSocket(Integer.parseInt(argv[0]),address);
            server_socket.setSoTimeout(30000);
// Creamos el socket del servidor
// Establecemos un timeout de 30 segs
            while (true) {
                byte[] aux = new byte[1024];
                DatagramPacket data = new DatagramPacket(aux,aux.length);
                server_socket.receive(data);
// Preparamos un datagrama para recepción
// Recibimos el mensaje
// Preparamos el datagrama que vamos a enviar
                data.setSocketAddress(data.getSocketAddress());
// Enviamos el mensaje
                server_socket.send(data);
            }
        } catch (SocketTimeoutException e) {
            System.err.println("30 segs sin recibir nada");
        } catch (Exception e) {
            System.err.println("Error: "+ e.getMessage());
            e.printStackTrace();
        } finally {
// Cerramos el socket
            server_socket.close();
        }
    }
}

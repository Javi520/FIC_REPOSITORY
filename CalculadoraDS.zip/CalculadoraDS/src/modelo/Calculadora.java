/*//iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.math.BigDecimal;
import java.math.MathContext;

/**
 *
 * @author Javito
 */
public class Calculadora {
    
    private BigDecimal[] operandos;
    //asi algun dia se le pueden meter mas//primer_operando, tercer_operando;
    //rev 1 comentario si algun dia quieren meter mas con lo que hay que cambiar van jodidos que mas 
    //les da darle otro enfoque que por supuesto no es este, no lo haria asi yo
    private Funcion Foperando;
    private CalculadoraEstados estado;
    private AStack memory_stack;//modifico la clase stack para fines de uso
    
    //METHODS
    
    public BigDecimal getprimer_operando() {
        return operandos[0];
    }

    public BigDecimal gettercer_operando() {
        return operandos[1];
    }

    public Funcion getsegundo_operando() {
        return Foperando;
    }

    public void setprimer_operando(BigDecimal operando) {
        this.operandos[0] = operando;
    }

    public void setsegundo_operando(Funcion operando) {
        this.Foperando = operando;
    }

    public void settercer_operando(BigDecimal tercer_operando) {
        this.operandos[1] = tercer_operando;
    }
    
    public void setEstado(CalculadoraEstados estado_en_el_que_quiero_estar) {
        this.estado = estado_en_el_que_quiero_estar;
    }

    public CalculadoraEstados getEstado() {
        return this.estado;
    }
    
    /*/·("&/·&!(/"&(!/·&/(6378268e7ywquenjhi2nid3q2n3di2q
    j32d19379m1d2789vm21937vm912vm3v123m8v123m
    JIDOAWIM/(·"M(V")MQ"·H"·"·HO("·V
    para acordarme, netbeans y sus comentarios por defecto, el color perfecto para no leerlos
    rev 1 ahora en rojo mola mas*/
    public String addOperand(char operando){/*INACABADO*//*no me gusta para los profes*/
            if(estado.addOperand(operando))
                return operando+"";//type cast a la javito
            else
                return "E";
    }
    
    public String addOperand(Funcion operando){/*ni tu tampoco, que te crees mas importante?, pues no sera por el big*/
        if(estado.addOperand(operando))
                return operando+"";//type cast a la javito
            else
                return "E";
    }

    public void setoperacion(Funcion operando) {
        this.Foperando = operando;
    }
    
    public Calculadora(){
        this.operandos = new BigDecimal[2];
        this.operandos[0] = BigDecimal.ZERO;
        this.operandos[1] = BigDecimal.ZERO;
        this.estado = new EsperandoPrimerOperando(this);
        this.memory_stack = new AStack();
    }
    
    /*OPERACIONES_ESPECIALES
    ....................
    ................
    ..........
    .......
    .....
    ..
    */
    public String equal(){
        return estado.equal();
    }
    
    public void clear() {
        estado.clear();
    }

    public void all_clear() {
        estado.all_clear();
    }
    
    /*MEMORIA_OPERACIONES
    ....................
    ...................
    ..............
    ..........
    ......
    ....
    ..
    .
    */
    public void memoryReCall() {
        //estado.addOperand(memory_stack.pop());
    }
    
    public void memoryStore() {
        //estado.addOperand(memory_stack.pop());
        memory_stack.push(estado.getOperand());
    }
    
    public void memoryAdd(){
        memory_stack.push(memory_stack.pop().add(estado.getOperand(), MathContext.UNLIMITED));
    }
    
    public void memorySubs(){
        memory_stack.push(memory_stack.pop().subtract(estado.getOperand(), MathContext.UNLIMITED));
    }
    
    public void memoryReset(){
        memory_stack.clear();
    }

    
}

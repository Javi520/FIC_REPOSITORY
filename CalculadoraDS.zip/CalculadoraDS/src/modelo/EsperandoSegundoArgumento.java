/*//iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.math.BigDecimal;

/**
 *
 * @author Javito
 */
public class EsperandoSegundoArgumento implements CalculadoraEstados{
    
    //ATRIBUTES
    Calculadora calc_interna = null;
    StringBuffer numero = new StringBuffer("0");
    
    @Override
    public boolean addOperand(char operando) throws UnsupportedOperationException {
        throw new UnsupportedOperationException("Not meant to be supported");
    }

    @Override
    public boolean addOperand(Funcion operando) throws UnsupportedOperationException {
        calc_interna.setsegundo_operando(operando);
        calc_interna.setEstado(new EsperandoTercerArgumento(calc_interna));
        return true;
    }

    public EsperandoSegundoArgumento(Calculadora calc) {
        this.calc_interna = calc;
    }
    
}

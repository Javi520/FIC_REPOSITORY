/*//iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 *
 * @author Javito
 */
public class FNP implements Funcion{

    @Override
    public BigDecimal operar(Calculadora calc) {
        return BigDecimal.ONE.divide(calc.getprimer_operando(), 10/*meanwhile*/, RoundingMode.HALF_UP);
    }

    @Override
    public String toString2() {
        return " 1/x ";
    }
    
}

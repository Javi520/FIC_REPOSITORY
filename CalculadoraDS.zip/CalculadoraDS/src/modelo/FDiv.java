/*//iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 *
 * @author Javito
 */
public class FDiv implements Funcion{

    @Override
    public BigDecimal operar(Calculadora calc) {
        return calc.getprimer_operando().divide(calc.gettercer_operando(), 10, RoundingMode.HALF_UP);
    }

    @Override
    public String toString2() {
        return " / ";
    }
    
}

/*//iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.math.BigDecimal;
import java.util.Stack;

/**
 *
 * @author Javito
 */
public class AStack extends Stack<BigDecimal>{
    private Stack<BigDecimal> compuesto = new Stack();

    @Override
    public synchronized BigDecimal peek() {
        try {
            return super.peek();
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }

    @Override
    public synchronized BigDecimal pop() {
        try {
            return super.pop();
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }

    @Override
    public BigDecimal push(BigDecimal e) {
        return super.push(e);
    }
    
}

/*//iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.math.BigDecimal;

/**
 *
 * @author Javito
 */
public class PosteriorAlEqual implements CalculadoraEstados{
    
    //ATRIBUTES
    Calculadora calc_interna = null;
    //String numero = "";//not so optimized to concat every number or comma here
    StringBuffer numero = new StringBuffer("");
    
    /*OVERRIDE_FUNCTIONS
    ...................
    .................
    ..............
    ............
    ........
    .....
    ..
    .
    */
    @Override
    public boolean addOperand(char operando){
        numero.append(operando);
        return true;
    }

    @Override
    public boolean addOperand(BigDecimal operando) {
        calc_interna.setprimer_operando(operando);
        return true;
    }

    @Override
    public boolean addOperand(Funcion operando){
        try{
            calc_interna.setprimer_operando(new BigDecimal(numero.toString()));
            calc_interna.setoperacion(operando);
            calc_interna.setEstado(new EsperandoSegundoOperando(calc_interna));
            System.out.println("esperando operando numero 2");
            return true;
        }
        catch(Exception e){
            numero = new StringBuffer("0");
            return false;
        }
    }
    
    @Override
    public BigDecimal getOperand() {
        return calc_interna.getprimer_operando();
    }

    @Override
    public String equal() {
        return calc_interna.getprimer_operando().stripTrailingZeros().toEngineeringString();
    }

    @Override
    public void all_clear() {
        numero = new StringBuffer("0");
    }

    @Override
    public void clear() {
        numero = new StringBuffer("0");
    }
    /*
    .
    ..
    .....
    ......
    .........
    ..........
    .........
    */

    public PosteriorAlEqual(Calculadora calc) {
        this.calc_interna = calc;
        numero = new StringBuffer("");
    }
    
}

/*//iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.math.BigDecimal;

/**
 *
 * @author Javito
 */
public class EsperandoSegundoOperando implements CalculadoraEstados{
    
    //ATRIBUTES
    Calculadora calc_interna = null;
    //String numero = "";//not so optimized to concat every number or comma here
    StringBuffer numero = new StringBuffer("");
    
    @Override
    public boolean addOperand(char operando) throws UnsupportedOperationException {
        numero.append(operando);
        return true;
    }

    @Override
    public boolean addOperand(Funcion operando) throws UnsupportedOperationException {
        if(numero==new StringBuffer(""))
            calc_interna.setoperacion(operando);
        else{
            calc_interna.settercer_operando(new BigDecimal(numero.toString()));
            calc_interna.setEstado(new EsperandoSegundoOperando(calc_interna));
        }
        return true;
    }

    public EsperandoSegundoOperando(Calculadora calc) {
        this.calc_interna = calc;
    }
    
    /**
     * como hace la calculadora de windows 10
    (no es mi modelo a seguir, es la que tenia a mano en este momento)
    */
    @Override
    public BigDecimal getOperand() {
        if(numero==new StringBuffer(""))
            return calc_interna.getprimer_operando();
        else
            return calc_interna.gettercer_operando();
    }
    
}

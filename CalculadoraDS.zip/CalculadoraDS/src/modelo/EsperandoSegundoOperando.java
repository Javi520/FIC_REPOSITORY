/*//iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.math.BigDecimal;

/**
 *
 * @author Javito
 */
public class EsperandoSegundoOperando implements CalculadoraEstados{
    
    //ATRIBUTES
    Calculadora calc_interna;
    //String numero = "";//not so optimized to concat every number or comma here
    StringBuffer numero = new StringBuffer("");
    
    @Override
    public boolean addOperand(char operando){
        numero.append(operando);
        System.out.println("appended "+operando);
        return true;
    }

    @Override
    public boolean addOperand(BigDecimal operando) {
        calc_interna.settercer_operando(operando);
        return true;
    }

    @Override
    public boolean addOperand(Funcion operando){
        //if(numero==(new StringBuffer(""))) vaya fallo
        if(numero.toString().equals(""))
            calc_interna.setoperacion(operando);
        else{
            System.out.println(numero);
            try{
                BigDecimal to_test = new BigDecimal(numero.toString());
                calc_interna.setprimer_operando(to_test);
                System.out.println(to_test==null);
                calc_interna.setEstado(new EsperandoSegundoOperando(calc_interna));
            }catch(Exception e){
                System.out.println("returning false");
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * como hace la calculadora de windows 10
    (no es mi modelo a seguir, es la que tenia a mano en este momento)
     * @return BigDecimal
    */
    @Override
    public BigDecimal getOperand() {
        if(numero.toString().equals(""))
            return calc_interna.getprimer_operando();
        else
            return calc_interna.gettercer_operando();
    }
    
    /**
     * como hace la calculadora de windows 10
    (no es mi modelo a seguir, es la que tenia a mano en este momento)
     * @return String
    */
    @Override
    public String equal() {
        Funcion operando2 = calc_interna.getsegundo_operando();
        System.out.println(operando2.toString());
        if(numero.toString().equals("")){
            System.out.println("marcador 0001 "+calc_interna.getprimer_operando());
            calc_interna.settercer_operando(calc_interna.getprimer_operando());
        }
        else
            calc_interna.settercer_operando(new BigDecimal(numero.toString()));
        System.out.println("marcador 0002 "+calc_interna.gettercer_operando());
        System.out.println("es el tercer operando nulo"+(calc_interna.gettercer_operando()==null));
        //mira que guay
        //System.out.println(calc_interna.getEstado().getClass().getName());
        //no dije nada pero es raro
        //me diceque 7 is this cuando el equal del esperandosegundo.... no tiene
        //fallo mio, no es un problema, eso lo dice *GUI
        calc_interna.setprimer_operando(operando2.operar(calc_interna));//por el principio de minimo conocimiento
        //es mejor que operar no modifique directamenta el objeto calculadora
        //calc_interna.setEstado(new EsperandoSegundoOperando(calc_interna));//renovar esta bien pero muy costoso, bueno no pero muy sucio
        calc_interna.setEstado(new EsperandoPrimerOperando(calc_interna));
        return calc_interna.getprimer_operando().stripTrailingZeros().toEngineeringString();
    }

    @Override
    public void all_clear() {
        System.out.println("voy al estado 1\n");
        calc_interna.setprimer_operando(BigDecimal.ZERO);//revisar
        calc_interna.setEstado(new EsperandoPrimerOperando(calc_interna));
    }

    @Override
    public void clear() {
        calc_interna.settercer_operando(BigDecimal.ZERO);
    }

    public EsperandoSegundoOperando(Calculadora calc) {
        this.calc_interna = calc;
    }
    
}

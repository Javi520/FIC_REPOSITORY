/*//iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.math.BigDecimal;

/**
 *
 * @author Javito
 */
public class EsperandoNoSeComoLLamarlo implements CalculadoraEstados{//lo voy a llamar la tragona porque traga con todo
    
    //ATRIBUTES
    Calculadora calc_interna = null;
    StringBuffer numero = new StringBuffer("");

    @Override
    public boolean addOperand(char operando) throws UnsupportedOperationException {
        numero.append(operando);
        return true;
    }

    @Override
    public boolean addOperand(Funcion operando) throws UnsupportedOperationException {
        calc_interna.setsegundo_operando(operando);
        //queda en el mismo estado sin problema
        return true;
    }

    public EsperandoNoSeComoLLamarlo(Calculadora calc) {
        this.calc_interna = calc;
    }
    
}

/*//iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.math.BigDecimal;

/**
 *
 * @author Javito
 */
public class EsperandoPrimerOperando implements CalculadoraEstados{
    
    //ATRIBUTES
    Calculadora calc_interna = null;
    //String numero = "";//not so optimized to concat every number or comma here
    StringBuffer numero = new StringBuffer("0");
    
    /*OVERRIDE_FUNCTIONS
    ...................
    .................
    ..............
    ............
    ........
    .....
    ..
    .
    */
    @Override
    public boolean addOperand(char operando){
        numero.append(operando);
        return true;
    }

    @Override
    public boolean addOperand(BigDecimal operando) {
        calc_interna.setprimer_operando(operando);
        return true;
    }

    @Override
    public boolean addOperand(Funcion operando){
        System.out.println("prueba"+numero.toString()+"0".equals(numero.toString()));
        //if("0".equals(numero.toString())){
        if(!numero.toString().equals("0")){
            try{
                calc_interna.setprimer_operando(new BigDecimal(numero.toString()));
                System.out.println("hola");
                calc_interna.setoperacion(operando);
                calc_interna.setEstado(new EsperandoSegundoOperando(calc_interna));
                System.out.println("esperando operando numero 2");
                return true;
            }
            catch(Exception e){
                numero = new StringBuffer("0");
                return false;
            }
        }
        else{
            System.out.println("no llego aqui");
            calc_interna.setoperacion(operando);
            calc_interna.setEstado(new EsperandoSegundoOperando(calc_interna));
            return true;
        }
    }
    
    @Override
    public BigDecimal getOperand() {
        return calc_interna.getprimer_operando();
    }

    @Override
    public String equal() {
        return calc_interna.getprimer_operando().stripTrailingZeros().toEngineeringString();
    }

    @Override
    public void all_clear() {
        numero = new StringBuffer("0");
        calc_interna.setprimer_operando(BigDecimal.ZERO);
    }

    @Override
    public void clear() {
        numero = new StringBuffer("0");
        calc_interna.setprimer_operando(BigDecimal.ZERO);
    }
    /*
    .
    ..
    .....
    ......
    .........
    ..........
    .........
    */

    public EsperandoPrimerOperando(Calculadora calc) {
        this.calc_interna = calc;
        numero = new StringBuffer("0");
    }
    
}

/*//iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.math.BigDecimal;

/**
 *
 * @author Javito
 */
public class EsperandoPrimerOperando implements CalculadoraEstados{
    
    //ATRIBUTES
    Calculadora calc_interna = null;
    //String numero = "";//not so optimized to concat every number or comma here
    StringBuffer numero = new StringBuffer("0");
    
    @Override
    public boolean addOperand(char operando) throws UnsupportedOperationException {
        numero.append(operando);
        return true;
    }

    @Override
    public boolean addOperand(Funcion operando) throws UnsupportedOperationException {
        try{
            calc_interna.setprimer_operando(new BigDecimal(numero.toString()));
            calc_interna.setoperacion(operando);
            calc_interna.setEstado(new EsperandoSegundoOperando(calc_interna));
            return true;
        }
        catch(Exception e){
            return false;
        }
    }
    
    @Override
    public BigDecimal getOperand() {
        return calc_interna.getprimer_operando();
    }

    public EsperandoPrimerOperando(Calculadora calc) {
        this.calc_interna = calc;
    }
    
}

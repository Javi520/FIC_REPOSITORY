/* //iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.math.BigDecimal;
import java.math.MathContext;

/**
 *
 * @author Javito
 */
public class FSuma implements Funcion{
    
    
    @Override
    public BigDecimal operar(Calculadora calc) {
        return (calc.getprimer_operando().add(calc.gettercer_operando(),MathContext.UNLIMITED));
    }

    @Override
    public String toString2()/*toString() no funciona la obligacion de implementarlo por que object ya lo hace y no lo detecta*/ {
        return " + ";
    }
    
}

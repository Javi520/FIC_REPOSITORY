/* //iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 *
 * @author Javito
 */
public class FSuma implements Funcion{
    
    
    @Override
    public BigDecimal operar(Calculadora calc) {
        return (calc.getprimer_operando().divide(calc.gettercer_operando(), /*de momento*/0, RoundingMode.UP));
    }

    @Override
    public String toString2()/*toString() no funciona la obligacion de implementarlo por que object ya lo hace y no lo detecta*/ {
        return " + ";
    }
    
}

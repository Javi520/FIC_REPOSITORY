/*//iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.math.BigDecimal;

/**
 *
 * @author Javito
 */
public class FSQR implements Funcion{

    @Override
    public BigDecimal operar(Calculadora calc) {
        return calc.getprimer_operando().pow(2);//to redefine
    }

    @Override
    public String toString2() {
        return " ^ ";
    }
    
}

/*//iwnbb
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.math.BigDecimal;


/**
 *
 * @author Javito
 */
public interface CalculadoraEstados {
    
    public boolean addOperand(char operando);
    public boolean addOperand(BigDecimal operando);
    public boolean addOperand(Funcion operando);
    public String equal();
    public void all_clear();
    public void clear();
    public BigDecimal getOperand();
    
}
